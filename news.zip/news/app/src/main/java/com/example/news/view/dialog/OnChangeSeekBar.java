package com.example.news.view.dialog;

public interface OnChangeSeekBar {
    void setOnChangeSeekBar(int position);
}
