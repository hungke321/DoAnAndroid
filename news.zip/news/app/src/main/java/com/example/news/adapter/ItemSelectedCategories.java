package com.example.news.adapter;

public interface ItemSelectedCategories {

    public void setOnItemSelectedItemCategories(int postion);
}
