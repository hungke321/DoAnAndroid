package com.example.news.view.dialog;

public interface OnCheckDialogMode {
    void setOnCheckDialogMode(final boolean value);
}
